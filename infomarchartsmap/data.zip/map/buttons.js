/* $(function () {
    $("#openFullButton")
      .button({
          text: false,
          icons: {
              primary: "ui-icon-wrench"
          }
      })
      .click(function (event) {
          event.preventDefault();
      });
});

$(function () {	
    $("#btnCloseShipwreck")
	.button({
        text: false,
        icons: {
            primary: "ui-icon-close"
        }
    })
	 .click(function (event) {
		    $("div#shipwreckModal").removeClass("show");
            $("div#modalMask").removeClass("show");
	 });
}); */